/**
 * Created by Gaming on 15.01.2016.
 */
chrome.devtools.panels.create(
    "TheNameOfYourExtension",
    "img/icon16.png",
    "index.html",
    function() {

    }
);